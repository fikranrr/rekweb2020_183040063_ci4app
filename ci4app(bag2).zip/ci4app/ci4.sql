-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2020 at 03:21 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4`
--

-- --------------------------------------------------------

--
-- Table structure for table `komik`
--

CREATE TABLE `komik` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `sampul` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `komik`
--

INSERT INTO `komik` (`id`, `judul`, `slug`, `penulis`, `penerbit`, `sampul`, `created_at`, `updated_at`) VALUES
(1, 'Naruto', 'naruto', 'Masashi Kishimoto', 'Shonen Jump', 'naruto.jpg', NULL, '2020-10-15 05:30:22'),
(2, 'One Piece', 'one-piece', 'Richiro Oda', 'Gramedia', 'one piece.jpg', NULL, NULL),
(5, 'coba', 'coba', 'test', 'test', '1-7.jpg', '2020-10-15 09:09:19', '2020-10-15 09:09:19'),
(6, 'asa', 'asa', 'as', 'as', '1602776070_72087f0b28367ea961db.jpg', '2020-10-15 09:15:55', '2020-10-15 10:34:30');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` text NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2020-10-15-154515', 'App\\Database\\Migrations\\Orang', 'default', 'App', 1602777330, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orang`
--

CREATE TABLE `orang` (
  `id` int(11) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orang`
--

INSERT INTO `orang` (`id`, `nama`, `alamat`, `created_at`, `updated_at`) VALUES
(1, 'Zalindra Hartati S.Ked', 'Ki. Pahlawan No. 314, Madiun 13562, Gorontalo', '1972-03-05 20:05:02', '2020-10-15 12:14:04'),
(2, 'Hardi Pratama', 'Dk. Ir. H. Juanda No. 632, Bogor 40237, Maluku', '1994-10-06 11:27:26', '2020-10-15 12:14:04'),
(3, 'Emong Nashiruddin', 'Ds. Sutoyo No. 201, Singkawang 66260, SulTra', '1983-01-08 18:42:49', '2020-10-15 12:14:04'),
(4, 'Rangga Ardianto', 'Dk. Raya Ujungberung No. 35, Serang 96490, KalSel', '1988-07-13 08:24:13', '2020-10-15 12:14:04'),
(5, 'Bakidin Tampubolon', 'Kpg. Barasak No. 592, Ambon 32735, KalTim', '1970-09-04 05:42:32', '2020-10-15 12:14:04'),
(6, 'Damar Adriansyah', 'Jr. Raya Ujungberung No. 713, Balikpapan 43205, NTT', '1990-10-02 09:23:12', '2020-10-15 12:14:04'),
(7, 'Yulia Mutia Kusmawati', 'Psr. Baiduri No. 769, Palu 42650, Maluku', '1982-09-30 00:55:03', '2020-10-15 12:14:04'),
(8, 'Hilda Tiara Nuraini', 'Gg. Dr. Junjunan No. 496, Tanjung Pinang 73137, SumUt', '2000-12-11 20:04:41', '2020-10-15 12:14:04'),
(9, 'Salwa Suryatmi S.T.', 'Dk. Bagas Pati No. 526, Tual 24432, Bali', '1978-10-29 01:29:14', '2020-10-15 12:14:04'),
(10, 'Gamblang Dabukke', 'Gg. R.E. Martadinata No. 517, Serang 78043, SumUt', '1984-12-21 03:37:49', '2020-10-15 12:14:04'),
(11, 'Farah Rahimah', 'Kpg. Baja Raya No. 916, Tidore Kepulauan 78403, KalTeng', '1970-11-19 17:28:58', '2020-10-15 12:14:04'),
(12, 'Kenzie Lazuardi', 'Jr. Hang No. 504, Madiun 23975, Aceh', '1999-05-17 11:40:42', '2020-10-15 12:14:04'),
(13, 'Janet Yuliarti', 'Gg. Halim No. 468, Depok 46317, SulTra', '1989-01-12 04:46:49', '2020-10-15 12:14:04'),
(14, 'Tomi Hidayanto S.IP', 'Psr. Ciumbuleuit No. 906, Banjarmasin 35012, BaBel', '1989-02-09 19:47:55', '2020-10-15 12:14:04'),
(15, 'Shania Salwa Sudiati M.Ak', 'Gg. PHH. Mustofa No. 373, Prabumulih 37605, KalTeng', '1985-06-02 20:19:28', '2020-10-15 12:14:04'),
(16, 'Yani Hassanah', 'Ki. Wahid No. 225, Administrasi Jakarta Utara 64835, SulSel', '1980-05-02 09:49:38', '2020-10-15 12:14:04'),
(17, 'Gasti Maryati', 'Jln. Dewi Sartika No. 838, Banda Aceh 40809, SulUt', '2010-06-10 16:12:09', '2020-10-15 12:14:04'),
(18, 'Jagaraga Kuswoyo', 'Gg. Raya Ujungberung No. 933, Pontianak 69103, SumBar', '1973-04-02 06:14:22', '2020-10-15 12:14:04'),
(19, 'Putri Sudiati', 'Psr. Bata Putih No. 605, Magelang 99906, SulTeng', '2001-10-01 09:23:42', '2020-10-15 12:14:04'),
(20, 'Bahuraksa Raihan Sirait', 'Ki. Yos Sudarso No. 717, Payakumbuh 86714, SulUt', '1995-11-26 08:34:16', '2020-10-15 12:14:04'),
(21, 'Kasusra Maryadi', 'Ki. Jaksa No. 362, Sorong 99619, SulSel', '1990-12-18 14:07:32', '2020-10-15 12:14:04'),
(22, 'Fathonah Nurdiyanti', 'Kpg. Baja Raya No. 11, Tanjung Pinang 12412, SulUt', '1992-06-20 19:50:11', '2020-10-15 12:14:04'),
(23, 'Harimurti Latupono', 'Gg. Gegerkalong Hilir No. 82, Prabumulih 77961, SulTra', '1980-05-10 06:56:54', '2020-10-15 12:14:04'),
(24, 'Elon Maryadi', 'Ds. Nanas No. 63, Blitar 82130, JaTeng', '2006-11-15 12:59:18', '2020-10-15 12:14:04'),
(25, 'Diah Yuniar', 'Jr. Yos Sudarso No. 220, Bengkulu 93940, JaTeng', '2011-01-22 23:49:26', '2020-10-15 12:14:04'),
(26, 'Eka Melani', 'Psr. Sukajadi No. 459, Metro 66149, SumBar', '1970-07-13 09:17:58', '2020-10-15 12:14:05'),
(27, 'Manah Marbun S.Sos', 'Dk. Arifin No. 489, Lubuklinggau 33513, Jambi', '1989-11-01 13:00:01', '2020-10-15 12:14:05'),
(28, 'Jaka Saefullah', 'Dk. Baladewa No. 552, Depok 19482, Riau', '2016-08-31 12:38:06', '2020-10-15 12:14:05'),
(29, 'Tira Intan Palastri S.IP', 'Gg. Bakau No. 123, Mojokerto 58622, Papua', '1992-12-16 03:49:36', '2020-10-15 12:14:05'),
(30, 'Naradi Latif Siregar', 'Gg. Banal No. 393, Salatiga 56088, Banten', '1993-02-08 10:39:38', '2020-10-15 12:14:05'),
(31, 'Chandra Nababan S.Psi', 'Jln. Salam No. 751, Palangka Raya 93871, SulTra', '1980-10-24 20:39:57', '2020-10-15 12:14:05'),
(32, 'Banara Jaka Prabowo', 'Kpg. Tangkuban Perahu No. 175, Administrasi Jakarta Utara 31080, Lampung', '1996-01-25 01:06:47', '2020-10-15 12:14:05'),
(33, 'Lidya Lestari', 'Ki. Surapati No. 182, Medan 56032, JaTim', '1991-01-03 00:51:45', '2020-10-15 12:14:05'),
(34, 'Rina Purnawati', 'Jln. Kyai Mojo No. 769, Kupang 59769, SumUt', '2020-07-27 18:12:24', '2020-10-15 12:14:05'),
(35, 'Najwa Zulaikha Palastri S.T.', 'Jr. Halim No. 819, Batu 13894, NTB', '1976-12-15 00:55:16', '2020-10-15 12:14:05'),
(36, 'Kemal Marpaung M.Pd', 'Dk. Barat No. 233, Bitung 37832, JaBar', '1974-05-24 22:15:50', '2020-10-15 12:14:05'),
(37, 'Elvina Hassanah', 'Gg. Salam No. 874, Singkawang 45436, Lampung', '1994-04-07 16:24:31', '2020-10-15 12:14:05'),
(38, 'Zulaikha Kusmawati', 'Dk. Surapati No. 639, Surakarta 85463, SulTra', '1980-11-20 12:56:35', '2020-10-15 12:14:05'),
(39, 'Salsabila Nasyiah S.Psi', 'Ki. Bakit  No. 95, Bandar Lampung 60350, NTB', '1988-04-02 08:10:13', '2020-10-15 12:14:05'),
(40, 'Hasim Megantara', 'Jln. Suryo Pranoto No. 876, Batu 92052, Riau', '1976-06-09 12:27:21', '2020-10-15 12:14:05'),
(41, 'Victoria Laksita', 'Jr. Fajar No. 860, Sorong 96377, NTB', '1987-05-29 04:28:22', '2020-10-15 12:14:05'),
(42, 'Jane Zulaika', 'Kpg. Bhayangkara No. 930, Pekanbaru 76308, JaBar', '2008-09-14 06:06:56', '2020-10-15 12:14:05'),
(43, 'Kenes Zulkarnain M.TI.', 'Ki. Zamrud No. 855, Cimahi 61795, KalUt', '1974-07-13 00:10:48', '2020-10-15 12:14:05'),
(44, 'Restu Yuniar', 'Gg. Suryo Pranoto No. 417, Banjarmasin 32223, KalTim', '2001-05-17 00:00:32', '2020-10-15 12:14:05'),
(45, 'Diah Usamah', 'Kpg. Adisumarmo No. 224, Bengkulu 34595, KalTim', '1999-10-15 16:14:59', '2020-10-15 12:14:05'),
(46, 'Ihsan Rajasa', 'Kpg. Baan No. 423, Tegal 50822, SumSel', '2000-12-09 07:10:26', '2020-10-15 12:14:05'),
(47, 'Calista Lalita Yulianti', 'Gg. Supono No. 842, Cirebon 69893, SumUt', '1977-05-11 23:00:17', '2020-10-15 12:14:06'),
(48, 'Saadat Tampubolon', 'Psr. Aceh No. 418, Surakarta 73982, Banten', '2010-04-05 00:40:41', '2020-10-15 12:14:06'),
(49, 'Victoria Oktaviani', 'Jln. Baan No. 168, Manado 75539, Papua', '1990-10-09 22:50:48', '2020-10-15 12:14:06'),
(50, 'Julia Widiastuti', 'Ds. Salam No. 8, Pekanbaru 96919, BaBel', '1987-06-05 06:53:21', '2020-10-15 12:14:06'),
(51, 'Dartono Widodo', 'Jln. Pahlawan No. 893, Tasikmalaya 16121, SumSel', '2012-08-04 01:47:49', '2020-10-15 12:14:06'),
(52, 'Chandra Wahyudin', 'Ds. Ir. H. Juanda No. 319, Pasuruan 35365, SumSel', '1990-04-29 17:08:31', '2020-10-15 12:14:06'),
(53, 'Usyi Hassanah', 'Jr. Mahakam No. 756, Tidore Kepulauan 11190, SumSel', '1991-10-19 06:09:14', '2020-10-15 12:14:06'),
(54, 'Irma Yance Usada S.Psi', 'Ds. Suryo Pranoto No. 491, Pariaman 72647, KalBar', '2007-06-24 22:33:49', '2020-10-15 12:14:06'),
(55, 'Heryanto Prasetyo', 'Jln. Basmol Raya No. 27, Banjarbaru 46887, JaTeng', '2011-01-09 09:55:47', '2020-10-15 12:14:06'),
(56, 'Kayla Kuswandari', 'Jln. Ters. Kiaracondong No. 898, Pagar Alam 58011, Bali', '2016-04-14 03:14:35', '2020-10-15 12:14:07'),
(57, 'Gara Latupono', 'Dk. Raya Ujungberung No. 978, Sawahlunto 27859, KalSel', '1970-10-02 10:56:11', '2020-10-15 12:14:07'),
(58, 'Puti Wulandari', 'Kpg. S. Parman No. 255, Bekasi 77079, Banten', '1988-04-16 18:25:27', '2020-10-15 12:14:07'),
(59, 'Almira Syahrini Yolanda', 'Ds. Suprapto No. 429, Pekanbaru 98605, Bali', '2019-06-22 23:43:57', '2020-10-15 12:14:07'),
(60, 'Ghani Galang Wijaya', 'Jr. Casablanca No. 86, Manado 88268, Maluku', '2013-08-17 09:37:46', '2020-10-15 12:14:07'),
(61, 'Zelaya Victoria Anggraini', 'Kpg. Bagonwoto  No. 789, Pangkal Pinang 29785, SulSel', '2012-06-20 07:22:09', '2020-10-15 12:14:07'),
(62, 'Ayu Nasyidah', 'Psr. Villa No. 794, Metro 82473, JaBar', '2017-01-02 10:32:02', '2020-10-15 12:14:07'),
(63, 'Rama Tugiman Marpaung M.Pd', 'Ds. Bak Mandi No. 921, Kediri 28675, KalSel', '1972-07-30 11:19:45', '2020-10-15 12:14:07'),
(64, 'Karen Andriani', 'Ds. Tambun No. 600, Gorontalo 75779, SumBar', '2005-08-10 22:35:17', '2020-10-15 12:14:07'),
(65, 'Elvina Mandasari S.H.', 'Jr. Babadak No. 392, Salatiga 15904, SumBar', '2007-05-17 22:06:44', '2020-10-15 12:14:07'),
(66, 'Warta Garang Ramadan M.TI.', 'Jr. Bayam No. 148, Bima 94503, NTB', '2015-02-13 04:25:07', '2020-10-15 12:14:07'),
(67, 'Parman Ramadan', 'Ds. Pattimura No. 307, Lhokseumawe 67353, Bali', '1996-08-07 13:50:20', '2020-10-15 12:14:07'),
(68, 'Rafi Tamba', 'Kpg. S. Parman No. 142, Dumai 64114, SumSel', '1981-05-15 21:05:13', '2020-10-15 12:14:07'),
(69, 'Lidya Usada', 'Gg. Gardujati No. 650, Madiun 77167, KalTeng', '1973-11-25 11:07:12', '2020-10-15 12:14:07'),
(70, 'Safina Purwanti', 'Kpg. Yogyakarta No. 442, Administrasi Jakarta Barat 85740, KalBar', '2002-08-14 01:03:24', '2020-10-15 12:14:07'),
(71, 'Zizi Laras Oktaviani', 'Kpg. Warga No. 805, Cirebon 26331, SulTra', '1970-07-29 16:56:52', '2020-10-15 12:14:07'),
(72, 'Karimah Haryanti', 'Dk. Salatiga No. 731, Sungai Penuh 57474, JaTim', '1995-03-18 01:04:27', '2020-10-15 12:14:07'),
(73, 'Karna Budiyanto', 'Ki. Casablanca No. 589, Pekanbaru 53759, SumUt', '2000-02-24 05:55:26', '2020-10-15 12:14:07'),
(74, 'Latika Andriani', 'Ds. Abdullah No. 476, Denpasar 79328, PapBar', '2009-09-11 04:59:44', '2020-10-15 12:14:07'),
(75, 'Uli Prastuti S.Gz', 'Dk. Imam No. 108, Probolinggo 48804, MalUt', '1982-06-05 03:52:17', '2020-10-15 12:14:08'),
(76, 'Endah Laksmiwati', 'Gg. Sutoyo No. 899, Kupang 56998, JaTeng', '1999-04-21 18:07:16', '2020-10-15 12:14:08'),
(77, 'Nadine Nasyiah', 'Dk. Suniaraja No. 898, Jayapura 38765, PapBar', '2015-07-07 06:30:57', '2020-10-15 12:14:08'),
(78, 'Umay Natsir', 'Dk. Ki Hajar Dewantara No. 185, Bima 49780, PapBar', '1989-11-02 05:41:11', '2020-10-15 12:14:08'),
(79, 'Ade Tantri Pratiwi M.Pd', 'Ds. Bawal No. 619, Sukabumi 57983, KalBar', '2007-04-10 14:35:20', '2020-10-15 12:14:08'),
(80, 'Parman Ganjaran Sihombing S.I.Kom', 'Ki. Panjaitan No. 113, Palopo 53886, SulUt', '2019-06-28 09:38:50', '2020-10-15 12:14:08'),
(81, 'Adiarja Wibowo', 'Jln. Untung Suropati No. 363, Banda Aceh 89512, KalUt', '1981-07-08 05:41:30', '2020-10-15 12:14:08'),
(82, 'Vega Eluh Hutagalung S.Pt', 'Dk. Cikutra Timur No. 674, Sorong 86150, Jambi', '1999-04-07 21:14:03', '2020-10-15 12:14:08'),
(83, 'Zaenab Titin Utami', 'Gg. Kebangkitan Nasional No. 463, Surabaya 14091, Aceh', '2013-06-02 14:51:42', '2020-10-15 12:14:08'),
(84, 'Ian Estiono Nababan S.Pt', 'Dk. R.E. Martadinata No. 792, Solok 62879, SulTra', '1994-03-21 19:49:23', '2020-10-15 12:14:08'),
(85, 'Jelita Prastuti', 'Jln. Orang No. 6, Pontianak 98307, KalTim', '2011-10-11 16:09:29', '2020-10-15 12:14:08'),
(86, 'Banara Rajata', 'Psr. Babah No. 612, Tual 97590, JaBar', '1985-08-12 07:54:18', '2020-10-15 12:14:08'),
(87, 'Farhunnisa Padmasari', 'Jr. Ikan No. 77, Pariaman 86260, Jambi', '1975-03-16 00:30:33', '2020-10-15 12:14:08'),
(88, 'Raden Situmorang S.I.Kom', 'Ds. Nanas No. 661, Padangpanjang 26232, SulTra', '1986-08-17 16:50:46', '2020-10-15 12:14:08'),
(89, 'Patricia Puspasari', 'Ki. Ters. Pasir Koja No. 474, Tebing Tinggi 70272, KalSel', '1992-06-25 22:01:51', '2020-10-15 12:14:08'),
(90, 'Yance Zaenab Mardhiyah', 'Jr. Jayawijaya No. 413, Administrasi Jakarta Timur 88041, SulBar', '2004-09-04 12:24:36', '2020-10-15 12:14:08'),
(91, 'Tania Yuliarti', 'Jln. Honggowongso No. 891, Manado 67941, MalUt', '2000-02-07 07:17:35', '2020-10-15 12:14:08'),
(92, 'Ajimin Sihombing', 'Ki. Sutarto No. 597, Tangerang 99374, Papua', '2015-12-30 07:27:09', '2020-10-15 12:14:08'),
(93, 'Ika Novitasari', 'Dk. Baranang Siang Indah No. 77, Pangkal Pinang 16726, KepR', '2010-01-21 09:52:53', '2020-10-15 12:14:09'),
(94, 'Candra Teddy Hidayat', 'Gg. Wora Wari No. 340, Cimahi 58308, DIY', '1998-12-15 20:05:35', '2020-10-15 12:14:09'),
(95, 'Kamila Astuti', 'Ki. Abang No. 692, Manado 10372, Lampung', '1971-11-07 19:39:01', '2020-10-15 12:14:09'),
(96, 'Bakda Nababan', 'Jln. Gatot Subroto No. 347, Langsa 12497, SulSel', '1989-11-17 12:26:22', '2020-10-15 12:14:09'),
(97, 'Cemani Ardianto', 'Jln. Abdul Rahmat No. 959, Palembang 61233, JaBar', '1982-07-19 07:04:01', '2020-10-15 12:14:09'),
(98, 'Kasiyah Laksmiwati', 'Kpg. Basuki Rahmat  No. 901, Tanjung Pinang 42003, Lampung', '1992-05-03 16:03:48', '2020-10-15 12:14:09'),
(99, 'Siska Padmasari', 'Kpg. Batako No. 84, Dumai 84689, JaBar', '2018-07-11 05:30:44', '2020-10-15 12:14:09'),
(100, 'Suci Wani Laksmiwati S.Kom', 'Psr. Sentot Alibasa No. 210, Yogyakarta 42116, Lampung', '1978-01-14 06:00:23', '2020-10-15 12:14:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `komik`
--
ALTER TABLE `komik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orang`
--
ALTER TABLE `orang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `komik`
--
ALTER TABLE `komik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orang`
--
ALTER TABLE `orang`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
