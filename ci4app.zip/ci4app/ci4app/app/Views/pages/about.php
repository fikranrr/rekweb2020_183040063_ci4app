<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsa cumque quisquam, error perferendis necessitatibus autem porro laudantium harum amet hic asperiores distinctio odit fugit voluptate a molestiae possimus! Illum!</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>